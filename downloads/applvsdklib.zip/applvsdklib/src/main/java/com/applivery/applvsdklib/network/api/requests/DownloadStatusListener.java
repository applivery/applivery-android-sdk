package com.applivery.applvsdklib.network.api.requests;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 9/1/16.
 */
public interface DownloadStatusListener {
  void updateDownloadPercentStatus(double percent);
}
