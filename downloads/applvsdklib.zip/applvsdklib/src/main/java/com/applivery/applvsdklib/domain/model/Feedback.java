package com.applivery.applvsdklib.domain.model;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 3/1/16.
 */
public interface Feedback {
  //TODO next release stuff
}
