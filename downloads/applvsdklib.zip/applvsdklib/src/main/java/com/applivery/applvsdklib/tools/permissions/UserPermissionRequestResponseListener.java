package com.applivery.applvsdklib.tools.permissions;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 17/1/16.
 */
public interface UserPermissionRequestResponseListener {
  void onPermissionAllowed(boolean permissionAllowed);
}
