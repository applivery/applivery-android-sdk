package com.applivery.applvsdklib.domain.exceptions;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 18/10/15.
 */
public class AppliverySdkNotInitializedException extends RuntimeException {
  public AppliverySdkNotInitializedException(String s) {

  }
}
