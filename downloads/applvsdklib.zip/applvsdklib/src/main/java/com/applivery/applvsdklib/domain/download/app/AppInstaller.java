package com.applivery.applvsdklib.domain.download.app;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 9/1/16.
 */
public interface AppInstaller {

  void installApp(String Path);
}
