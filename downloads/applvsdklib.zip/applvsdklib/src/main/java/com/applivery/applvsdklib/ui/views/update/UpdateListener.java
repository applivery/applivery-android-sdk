package com.applivery.applvsdklib.ui.views.update;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 10/1/16.
 */
public interface UpdateListener {
  void onUpdateButtonClick();
  void setUpdateView(UpdateView updateView);
}
