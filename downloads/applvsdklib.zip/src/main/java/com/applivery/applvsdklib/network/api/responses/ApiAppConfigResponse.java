package com.applivery.applvsdklib.network.api.responses;

import com.applivery.applvsdklib.network.api.model.ApiAppConfigData;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 18/10/15.
 */
public class ApiAppConfigResponse extends ServerResponse<ApiAppConfigData> {
}
