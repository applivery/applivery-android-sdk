package com.applivery.applvsdklib.domain.appconfig.update;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 10/1/16.
 */
public interface CurrentAppInfo {
  long getVersionCode();
}
