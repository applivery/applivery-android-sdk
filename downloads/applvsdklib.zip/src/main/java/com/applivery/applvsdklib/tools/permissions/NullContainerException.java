package com.applivery.applvsdklib.tools.permissions;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 18/1/16.
 */
public class NullContainerException extends RuntimeException {
  public NullContainerException(String detailMessage) {
    super(detailMessage);
  }
}
