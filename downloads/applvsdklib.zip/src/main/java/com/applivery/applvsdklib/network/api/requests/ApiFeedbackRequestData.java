package com.applivery.applvsdklib.network.api.requests;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 3/1/16.
 */
public class ApiFeedbackRequestData {

  //TODO next release stuff

}
