package com.applivery.applvsdklib.domain.model;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 8/11/15.
 */
public interface BusinessObject<Data> {
  Data getObject();
}
