package com.applivery.applvsdklib.tools.androidimplementations;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 18/1/16.
 */
public enum PhoneStatusType {
  FOREGROUND,
  BACKGROUND
}
