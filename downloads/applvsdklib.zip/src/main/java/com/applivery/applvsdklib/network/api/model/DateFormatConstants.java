package com.applivery.applvsdklib.network.api.model;

public class DateFormatConstants {
  public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
}
