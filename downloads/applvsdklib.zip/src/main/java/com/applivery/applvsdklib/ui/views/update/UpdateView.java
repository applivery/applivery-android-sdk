package com.applivery.applvsdklib.ui.views.update;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 3/1/16.
 */
public interface UpdateView {
  void showUpdateDialog();

  void hideDownloadInProgress();

  void showDownloadInProgress();

  void updateProgress(double percent);
}
