package com.applivery.applvsdklib.network.api.responses;

import com.applivery.applvsdklib.network.api.model.ApiBuildTokenData;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 3/1/16.
 */
public class ApiBuildTokenResponse extends ServerResponse<ApiBuildTokenData> {
}
