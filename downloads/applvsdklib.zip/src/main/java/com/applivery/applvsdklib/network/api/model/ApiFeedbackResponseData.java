package com.applivery.applvsdklib.network.api.model;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 2/1/16.
 */
public class ApiFeedbackResponseData {
  //TODO next release stuff
}
