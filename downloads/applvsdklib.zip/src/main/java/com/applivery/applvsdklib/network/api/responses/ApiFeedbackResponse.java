package com.applivery.applvsdklib.network.api.responses;

import com.applivery.applvsdklib.network.api.requests.ApiFeedbackRequestData;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 2/1/16.
 */
public class ApiFeedbackResponse extends ServerResponse<ApiFeedbackRequestData> {
}
