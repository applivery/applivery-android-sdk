package com.applivery.applvsdklib.tools.androidimplementations;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 5/3/16.
 */
public interface AppPathReceiver {
  void onPathReady(String path);
}
