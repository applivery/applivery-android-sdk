package com.applivery.applvsdklib.usecases;

import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 24/1/16.
 */
//@RunWith(MockitoJUnitRunner.class)
public class AppConfigInteractorTest {


  public void should() {

  }
}
