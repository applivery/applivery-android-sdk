package com.applivery.applvsdklib.tools.permissions.utils;

/**
 * Created by Sergio Martinez Rodriguez
 * Date 18/1/16.
 */
public class StubString {
  public static final int FAKE_RES = 3;

  public int getPermissionDeniedFeedback() {
    return FAKE_RES;
  }

  public int getPermissionRationaleMessage() {
    return FAKE_RES;
  }

  public int getPermissionRationaleTitle() {
    return FAKE_RES;
  }
}
